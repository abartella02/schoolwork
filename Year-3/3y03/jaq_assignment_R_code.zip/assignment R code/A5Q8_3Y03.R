hic<-crash$hic

qqnorm(hic,pch=19,col="blue",datax=T)
qqline(hic,col="green",datax=T)

library("nortest")
ad.test(hic)

lnhic<-log(crash$hic)
crash<-cbind(crash,lnhic)

qqnorm(lnhic,pch=19,col="blue",datax=T)
qqline(lnhic,col="green",datax=T)

library("nortest")
ad.test(lnhic)