#chest_decel<-crash$chest.decel
#sum(chest_decel,na.rm=TRUE)

chest_decel<-crash$chest.decel
chest_decel<-chest_decel[!is.na(chest_decel)]
n<-length(chest_decel)
n

xbar<-mean(chest_decel)
s<-sd(chest_decel)
cbind(n,xbar,s)

alpha<-.05
tval<-qt(1-alpha/2,n-1)
tval

se<-s/sqrt(n)
c(xbar-tval*se,xbar+tval*se)

t.test(chest_decel,conf.level=.95)