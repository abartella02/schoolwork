wt<-crash$wt
wt_kg<-wt*0.4536

mean(wt_kg)

library("aplpack")
stem.leaf(wt_kg,na.rm=T,trim.outliers=F)

stem.leaf(wt_kg,na.rm=T,trim.outliers=F,m=1)

