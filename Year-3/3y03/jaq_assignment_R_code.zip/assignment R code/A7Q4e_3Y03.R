x<-c(1,4,10,6,13)
y<-c(10,6,6,4,1)
reg<-lm(x~y)
summary(reg)

#the value at Pr(>|t|)column and y row