#lleg<-crash$l.leg
#sum(lleg,na.rm=TRUE)

#protection=crash$protection
#table(protection)

lleg<-crash$l.leg
protection<-crash$protection

dairbag_lleg<-lleg[protection=="d airbag"]
dpairbags_lleg<-lleg[protection=="d&p airbags"]
manualbelts_lleg<-lleg[protection=="manual belts"]
motorizedbelts_lleg<-lleg[protection=="Motorized belts"]
passivebelts_lleg<-lleg[protection=="passive belts"]

cutpoints<-c(0,500,1000,1500,2000,2500,3000,3500)

hist(dairbag_lleg,breaks=cutpoints,labels=TRUE,right=FALSE,col="green",
   xaxt="n",main="d airbag left femur load",xlab="left femur load")
axis(side=1,at=cutpoints)

hist(dpairbags_lleg,breaks=cutpoints,labels=TRUE,right=FALSE,col="green",
   xaxt="n",main="d&p airbags left femur load",xlab="left femur load")
axis(side=1,at=cutpoints)

hist(manualbelts_lleg,breaks=cutpoints,labels=TRUE,right=FALSE,col="green",
   xaxt="n",main="manual belts left femur load",xlab="left femur load")
axis(side=1,at=cutpoints)

hist(motorizedbelts_lleg,breaks=cutpoints,labels=TRUE,right=FALSE,col="green",
   xaxt="n",main="motorized belts left femur load",xlab="left femur load")
axis(side=1,at=cutpoints)

hist(passivebelts_lleg,breaks=cutpoints,labels=TRUE,right=FALSE,col="green",
   xaxt="n",main="passive belts left femur load",xlab="left femur load")
axis(side=1,at=cutpoints)
