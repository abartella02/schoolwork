sample1<-c(4.2,4.5,3.4)
sample2<-c(4.5,2.5,2.3)
sample3<-c(1.2,-0.3,0.8,2.8)

blood_pressure<-c(sample1,sample2,sample3)
blood_pressure

sample<-c(rep("1",3),rep("2",3),rep("3",4))
sample

anova<-aov(blood_pressure ~ sample)
plot(anova,2,pch=19,col="red")

plot(anova,1,pch=19,col="red")

library("nortest")
ad.test(anova$residuals)

bartlett.test(blood_pressure ~ sample)

summary(anova)

pairwise.t.test(blood_pressure, sample, p.adj = "bonf")