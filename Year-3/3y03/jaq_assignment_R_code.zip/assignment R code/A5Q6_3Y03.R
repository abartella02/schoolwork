hic<-crash$hic
size<-crash$size
sum(hic,na.rm=TRUE)

bplot<-boxplot(hic~size,data=databank,main=
  "Boxplot of Head Injury Criterion by Vehicle Size",
   xlab="Head Injury Criterion",ylab="Vehicle Size",col="lightslateblue")

stats<-bplot$stats
stats

rownames(stats)<-c("a2","Q1","Q2","Q3","a1")
colnames(stats)<-bplot$names
stats

outliers<-bplot$out
sort(outliers,decreasing=FALSE)

hic<-crash$hic
size<-crash$size

mean<-tapply(hic,size,mean,na.rm=T)
sd<-tapply(hic,size,sd,na.rm=T)
n<-tapply(hic,size,length)

cbind(n,mean,sd)

min(hic,na.rm=TRUE)
max(hic,na.rm=TRUE)