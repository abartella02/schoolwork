lnhic<-log(crash$hic)
crash<-cbind(crash,lnhic)
lnhic<-crash$lnhic
mean(lnhic,na.rm=TRUE)
wt<-crash$wt
mean(wt,na.tm=TRUE)

reg<-lm(lnhic ~ wt,data=crash)
summary(reg)
anova(reg)

plot(reg,2,pch=19,col="blue")

plot(reg,1,pch=19,col="red")