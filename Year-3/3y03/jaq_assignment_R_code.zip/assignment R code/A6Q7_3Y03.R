body_temp<-c(98.2, 98.5, 98.5, 98.6, 97.5, 98.4, 98.0)

t.test(body_temp,mu=98.6,alt="less",conf.level=.95)

xbar<-mean(body_temp)
s<-sd(body_temp)
n<-length(body_temp)
cbind(n,xbar,s)

mu0<-98.6
tval<-(xbar-mu0)/(s/sqrt(n))
tval

pval= 1- pt(abs(tval),n-1)
pval