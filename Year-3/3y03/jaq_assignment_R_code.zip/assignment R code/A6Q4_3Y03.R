#rleg<-crash$r.leg
#sum(rleg,na.rm=TRUE)

rleg<-crash$r.leg
rleg<-rleg[!is.na(rleg)]
n<-length(rleg)
n

successes<-rleg[rleg>=1500]
successes

x<-length(successes)
x

alpha<-.06
zval<-qnorm(1-alpha/2)
zval

phat<-x/n
se<-sqrt(phat*(1-phat)/n)
c(phat-zval*se,phat+zval*se)

