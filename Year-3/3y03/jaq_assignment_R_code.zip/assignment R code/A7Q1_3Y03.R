size<-crash$size
size<-table(size)
size

t.test(lnhic~size,data=crash,alt="two.sided",
       conf.level=.99,var.equal=FALSE,na.action="na.omit",subset=(size == "comp" | size == "med"))
